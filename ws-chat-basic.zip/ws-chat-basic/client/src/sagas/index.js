import { takeLatest } from 'redux-saga/effects';
import ACTION_TYPES from './../actions/actionTypes';

function * rootSaga () {}

export default rootSaga;
